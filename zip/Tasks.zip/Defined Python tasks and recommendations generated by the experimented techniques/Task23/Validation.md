1:  sum += float(line[column_name])
    count += 1
2:  count += float(line[column_name])
    sum += count
3:  sum = line[column_name]
    count = 1
