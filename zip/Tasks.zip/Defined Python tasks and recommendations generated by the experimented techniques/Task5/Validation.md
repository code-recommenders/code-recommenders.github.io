1: for i in range(len(words)):
2: while to_return == "":
3: for i in words: