1: in numbers:
2: in range(1, len(numbers)):
3: in numbers.split():