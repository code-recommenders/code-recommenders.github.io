1: matrix [0, y] = y
2: matrix [y, 0] = x
3: matrix [y, 0] = x+y