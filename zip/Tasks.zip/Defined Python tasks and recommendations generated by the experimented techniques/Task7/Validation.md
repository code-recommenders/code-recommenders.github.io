1: mysock.close()
2: mysock.disconnect((host, 80))
3: return mysock