import urllib, requests
import re
import pdfkit

desktop_path = '/Users/User/Desktop/'
url = "https://en.wikipedia.org/wiki/International_Conference_on_Software_Engineering"

def create_pdf(desktop_path, url):
	#Get the html code
	response = urllib.request.urlopen(url)
	html = response.read().decode('utf-8')

	#Get the text in the <title> tag
	title = re.search(r'<title>(.*?)</title>', html).group(1)

	#Write the string in the PDF
	<TO COMPLETE>