1: if distances[i] > maxDistance:
2: if distances[i] > 0:
3: if distances[i] > distances[i-1]: