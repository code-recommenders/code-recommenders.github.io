1:  while len(self._observations) > self._overlap:
        self._observations.pop(0)
2:  while len(self._observations) > self._overlap:
        self._observations.pop(len(self._observations)-1)
3:  while len(self._observations) != self._overlap:
        self._observations.pop(0)