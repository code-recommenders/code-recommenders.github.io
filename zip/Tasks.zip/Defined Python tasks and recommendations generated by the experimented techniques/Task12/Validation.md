1: str(i[0]).upper()
2: str(i).upper()
3: str(text[0]).upper()