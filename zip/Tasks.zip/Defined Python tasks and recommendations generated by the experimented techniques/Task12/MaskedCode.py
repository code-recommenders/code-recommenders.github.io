def create_acronym():
	user_input = str(input("Enter a Phrase: "))
	text = user_input.split()
	a = ""
	for i in text:
	    a = a+<TO COMPLETE>
	print(a)