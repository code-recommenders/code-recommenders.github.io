import mysql.connector

def create_database():

	connector = mysql.connector.connect(
	  host="localhost",
	  user="root",
	  password="passw0rD"
	)

	cursor = connector.cursor()
	<TO COMPLETE>