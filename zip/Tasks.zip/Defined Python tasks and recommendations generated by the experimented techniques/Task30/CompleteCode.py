import speech_recognition as sr 
import moviepy.editor as mp
from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip

def process_chunk(list_minutes, i):
    ffmpeg_extract_subclip("my_video.mp4", list_minutes[i]-2*(list_minutes[i]!=0), list_minutes[i+1], targetname="chunks/cut{}.mp4".format(i+1))
    clip = mp.VideoFileClip(r"chunks/cut{}.mp4".format(i+1)) 
    clip.audio.write_audiofile(r"audios/converted{}.wav".format(i+1))
    r = sr.Recognizer()
    audio = sr.AudioFile("audios/converted{}.wav".format(i+1))
    with audio as source:
      r.adjust_for_ambient_noise(source)  
      audio_file = r.record(source)
    result = r.recognize_google(audio_file)
    return result

num_seconds_video= 52*60
print("The video is {} seconds".format(num_seconds_video))
list_minutes=list(range(0,num_seconds_video+1,60))

def recognize_speech(list_minutes):
    diz={}
    for i in range(len(list_minutes)-1):
        diz['chunk{}'.format(i+1)]=process_chunk(list_minutes, i)
    l_chunks=[diz['chunk{}'.format(i+1)] for i in range(len(diz))]
    text='\n'.join(l_chunks)

    # you need to create a text document to store all the text that has been extracted from the video:
    with open('recognized.txt',mode ='w') as file: 
       file.write("Recognized Speech:") 
       file.write("\n") 
       file.write(text) 
       print("Finally ready!")