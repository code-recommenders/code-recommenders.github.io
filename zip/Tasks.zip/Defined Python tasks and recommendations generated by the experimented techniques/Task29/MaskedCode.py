import os
import datetime


def has_date(text):
    try:
        datetime.datetime.strptime(text, '%d-%m-%Y')
        return True
    except ValueError:
        return False


folder_path = "/Users/User/Desktop"

def print_names(folder_path):
	# Recursively search in the directory
	for root, d_names, f_names in os.walk(folder_path):
	    # We only focus on file names (no directories)
	    for name in f_names:
	        <TO COMPLETE>





