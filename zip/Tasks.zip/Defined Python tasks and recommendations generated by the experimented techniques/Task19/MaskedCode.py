import os
from typing import Tuple

def print_file_content_of_working_dir(allowed_extensions: Tuple[str]) -> None:
    for root, dirs, files in os.walk(os.getcwd()):
        for file in files:
            if file.endswith(allowed_extensions):
                with open(root + "/" + file) as in_file:
                    print(in_file.<TO COMPLETE>