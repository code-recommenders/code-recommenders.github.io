1: readlines())
2: readfirstline())
3: flush())