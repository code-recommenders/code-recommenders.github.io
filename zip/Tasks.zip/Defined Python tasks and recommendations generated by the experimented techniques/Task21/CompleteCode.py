import urllib, requests
import re

web_page = "https://www.google.com"

def print_image_names(web_page):
	# Collect the HTML text in the webpage
	response = urllib.request.urlopen(web_page)
	html = response.read().decode('utf-8')

	# Get the text in the src attribute
	images = re.findall(r'src="(.*?).jpg"', html)
	only_name = []

	# Get the file name from the path
	for image in images:
	    tokens = str(image).split("/")
	    only_name.append(tokens[len(tokens) - 1] + ".jpg")

	# Sort array in reverse order
	only_name.sort(reverse=True)

	# Print the array elements
	for image in only_name:
	    print(image)