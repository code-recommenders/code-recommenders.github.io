1:  tokens = str(image).split("/")
    only_name.append(tokens[len(tokens) - 1] + ".jpg")
2:  tokens = str(image).split(" ")
    only_name.append(tokens[len(tokens)] + ".jpg")
3:  image_name = str(image).split()[-1] + ".jpg"
    only_name.append(image_name)