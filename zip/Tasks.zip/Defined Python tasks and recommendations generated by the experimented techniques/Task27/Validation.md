1:  url = tag.get("href")
     if url is not None and "articles" in url:
        print("\n" + url)
2:  url = tag.get("href")
     if url is not None and url == "articles":
        print("\n" + url)
3:  href = tag.get("attribute")
     if href is not None and "url" in href:
        print("\n" + href)