import csv

csv_path = '/Users/User/publications/inprogress/code-completion-quality/tasks/airports.csv'

def get_airports():
	airports_in_asia = []

	# Get the airports in Asia
	with open(csv_path) as airports:
	    reader = csv.reader(airports, delimiter=',')

	    # Iterate through the line sof the CSV
	    for line in reader:
	            if line[11].startswith("Asia/"):
	                airports_in_asia.append(line[1])

	# Sort the array
	airports_in_asia.sort()

	# Print the array
	for airport in airports_in_asia:
	    print(airport)
